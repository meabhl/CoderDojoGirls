# Week 4 November 29th
This week we focused on a couple of new css styles.

1. Padding
	- We added padding to our container div which created space between the 
	border of our container div and the elements inside the container.
2. Border
	- We experiemented adding different border types to our container
	e.g. *border: 5px dashed purple;*
	-- The first number is the width
	-- The second is the border type (dashed/solid/inset etc.)
	
3. Text styling
	- We learned how to add cool shadows to our heading
	-- *text-shadow: 10px 8px 6px purple;*
	--- The horizontal shadow (10px)
	--- The vertical shadow (8px)
	--- How much to blur the shadow (6px)
	--- The colour of the shadow (purple)
	
4. Side by side images
	- We learned how to put two images side by side.
	Remember: If the box the images are in is too small they won't fit
	beside each other!! (e.g. check the div the images are in!)
	
Hope you enjoyed styling your site!! 