

//Change the style of the bird image to hide the picture
function hideBird() {
 bird.style.display="none";
}

//Change the style of the bird to show the picture
function showBird() { 
 bird.style.display="block";
}


